package com.example.autocaptions

import android.app.Activity
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File

/** Exporte un MP4 avec les sous-titres incrustés (Media3 Transformer + overlay). */
object Exporter {

    fun export(
        activity: Activity,
        uri: Uri,
        renderer: CaptionRenderer,
        onProgress: (Int) -> Unit,
        onDone: (Uri?, String?) -> Unit
    ) {
        val (w, h) = videoSize(activity, uri)
        val overlay = CaptionBitmapOverlay(renderer, w, h)
        val effects = Effects(emptyList<AudioProcessor>(), listOf(OverlayEffect(ImmutableList.of(overlay))))
        val item = EditedMediaItem.Builder(MediaItem.fromUri(uri)).setEffects(effects).build()

        val out = File(activity.cacheDir, "captioned_${System.currentTimeMillis()}.mp4")
        val handler = Handler(Looper.getMainLooper())
        lateinit var transformer: Transformer

        val poll = object : Runnable {
            override fun run() {
                val ph = ProgressHolder()
                if (transformer.getProgress(ph) != Transformer.PROGRESS_STATE_NOT_STARTED) onProgress(ph.progress)
                handler.postDelayed(this, 300)
            }
        }

        transformer = Transformer.Builder(activity)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacks(poll)
                    Thread {
                        val saved = try { saveToGallery(activity, out) } catch (e: Exception) { null }
                        handler.post { onDone(saved, if (saved == null) "Enregistrement impossible" else null) }
                    }.start()
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    handler.removeCallbacks(poll)
                    onDone(null, exportException.message ?: "erreur inconnue")
                }
            })
            .build()

        transformer.start(item, out.absolutePath)
        handler.post(poll)
    }

    private fun videoSize(activity: Activity, uri: Uri): Pair<Int, Int> {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(activity, uri)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            return Pair(w, h)
        } finally {
            r.release()
        }
    }

    private fun saveToGallery(activity: Activity, file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "captions_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AutoCaptions")
        }
        val dest = activity.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        activity.contentResolver.openOutputStream(dest)?.use { o -> file.inputStream().use { it.copyTo(o) } }
        file.delete()
        return dest
    }

    /**
     * Bitmap transparent de la taille de la vidéo, redessiné à chaque image.
     * Deux bitmaps en alternance : Media3 ne ré-uploade la texture que si l'instance change.
     */
    private class CaptionBitmapOverlay(
        private val renderer: CaptionRenderer,
        private val w: Int,
        private val h: Int
    ) : BitmapOverlay() {
        private val bitmaps = arrayOf(
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888),
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        )
        private var flip = 0

        override fun getBitmap(presentationTimeUs: Long): Bitmap {
            flip = 1 - flip
            val bmp = bitmaps[flip]
            bmp.eraseColor(Color.TRANSPARENT)
            renderer.draw(Canvas(bmp), w, h, presentationTimeUs / 1000)
            return bmp
        }
    }
}
