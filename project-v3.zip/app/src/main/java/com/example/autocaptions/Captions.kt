package com.example.autocaptions

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

data class Word(val text: String, val startMs: Long, val endMs: Long)

/** Un groupe de 1 à 3 mots affiché en même temps (comme sur TikTok / CapCut). */
data class Chunk(val words: List<Word>, val showUntilMs: Long) {
    val startMs: Long get() = words.first().startMs
}

enum class CaptionStyle(val label: String) {
    BUBBLE("Bulle rose (1 mot)"),
    POP("Pop jaune"),
    BOX("Boîte violette"),
    BOUNCE("Rebond vert")
}

object Captions {
    fun buildChunks(words: List<Word>, maxWords: Int = 3, maxGapMs: Long = 600): List<Chunk> {
        val groups = mutableListOf<List<Word>>()
        var cur = mutableListOf<Word>()
        for (w in words) {
            if (cur.isNotEmpty() && (cur.size >= maxWords || w.startMs - cur.last().endMs > maxGapMs)) {
                groups += cur.toList()
                cur = mutableListOf()
            }
            cur += w
        }
        if (cur.isNotEmpty()) groups += cur.toList()

        return groups.mapIndexed { i, g ->
            val nextStart = groups.getOrNull(i + 1)?.first()?.startMs ?: Long.MAX_VALUE
            Chunk(g, min(g.last().endMs + 300, nextStart))
        }
    }
}

private fun easeOutBack(x: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    return 1f + c3 * (x - 1f).pow(3) + c1 * (x - 1f).pow(2)
}

/**
 * Dessine les sous-titres animés. Utilisé à la fois pour l'aperçu à l'écran
 * et pour l'export MP4, donc le rendu est identique.
 */
class CaptionRenderer {
    @Volatile private var flat: List<Word> = emptyList()
    @Volatile var chunks: List<Chunk> = emptyList()
        set(value) {
            field = value
            flat = value.flatMap { it.words }
        }
    @Volatile var style: CaptionStyle = CaptionStyle.BUBBLE

    private var bubbleFont: Typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)

    private val font = Typeface.create("sans-serif-black", Typeface.NORMAL)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = font }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = font
        this.style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        color = Color.BLACK
    }
    private val box = Paint(Paint.ANTI_ALIAS_FLAG)

    private val yellow = Color.parseColor("#FFE500")
    private val green = Color.parseColor("#39FF88")
    private val purple = Color.parseColor("#7C3AED")
    private val pink = Color.parseColor("#E91EC8")
    private val glowPink = Color.parseColor("#FF2BD6")

    // Style « bulle » : un seul mot, blanc, gros contour rose + halo + ombre, animation pop
    private val bFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = bubbleFont
        color = Color.WHITE
    }
    private val bStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = bubbleFont
        this.style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        color = pink
    }
    private val bGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = bubbleFont
        this.style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        color = glowPink
    }
    private val bShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = bubbleFont
        this.style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        color = Color.BLACK
    }

    /** Charge la police arrondie (assets/LilitaOne-Regular.ttf). Sinon, police système. */
    fun loadFont(ctx: Context) {
        try {
            bubbleFont = Typeface.createFromAsset(ctx.assets, "LilitaOne-Regular.ttf")
            for (p in listOf(bFill, bStroke, bGlow, bShadow)) p.typeface = bubbleFont
        } catch (_: Exception) {
        }
    }

    /** Mot affiché à l'instant t : il reste jusqu'au mot suivant, ou 250 ms après sa fin. */
    private fun wordAt(t: Long): Word? {
        val list = flat
        for (i in list.indices) {
            val w = list[i]
            if (t < w.startMs) return null
            val next = list.getOrNull(i + 1)
            val until = if (next != null && next.startMs - w.endMs < 350) next.startMs else w.endMs + 250
            if (t < until) return w
        }
        return null
    }

    private fun drawBubble(canvas: Canvas, w: Int, h: Int, tMs: Long) {
        val word = wordAt(tMs) ?: return
        val text = word.text.uppercase()
        val age = (tMs - word.startMs).toFloat().coerceAtLeast(0f)
        val scale = 0.5f + 0.5f * easeOutBack((age / 170f).coerceIn(0f, 1f))
        val a = ((age / 60f).coerceIn(0f, 1f) * 255).toInt()

        var size = min(w, h) * 0.15f
        bFill.textSize = size
        var tw = bFill.measureText(text)
        val maxW = w * 0.85f
        if (tw > maxW) {
            size *= maxW / tw
            tw = maxW
        }
        for (p in listOf(bFill, bStroke, bGlow, bShadow)) p.textSize = size
        bStroke.strokeWidth = size * 0.2f
        bGlow.strokeWidth = size * 0.26f
        bGlow.setShadowLayer(size * 0.3f, 0f, 0f, glowPink)
        bShadow.strokeWidth = size * 0.2f

        canvas.save()
        canvas.translate(w / 2f, h * (if (h >= w) 0.68f else 0.80f))
        canvas.scale(scale, scale)
        val x = -tw / 2f

        bShadow.color = Color.BLACK
        bShadow.alpha = a * 110 / 255
        canvas.drawText(text, x, size * 0.07f, bShadow)
        bGlow.color = glowPink
        bGlow.alpha = a
        canvas.drawText(text, x, 0f, bGlow)
        bStroke.color = pink
        bStroke.alpha = a
        canvas.drawText(text, x, 0f, bStroke)
        bFill.color = Color.WHITE
        bFill.alpha = a
        canvas.drawText(text, x, 0f, bFill)
        canvas.restore()
    }

    fun draw(canvas: Canvas, w: Int, h: Int, tMs: Long) {
        if (style == CaptionStyle.BUBBLE) {
            drawBubble(canvas, w, h, tMs)
            return
        }
        val chunk = chunks.firstOrNull { tMs >= it.startMs && tMs < it.showUntilMs } ?: return
        val st = style
        val portrait = h >= w

        var size = min(w, h) * 0.115f
        fill.textSize = size
        val texts = chunk.words.map { it.text.uppercase() }
        var gap = size * 0.28f
        var widths = texts.map { fill.measureText(it) }
        var total = widths.sum() + gap * (texts.size - 1)
        val maxW = w * 0.9f
        if (total > maxW) {
            val k = maxW / total
            size *= k
            gap *= k
            widths = widths.map { it * k }
            total = maxW
            fill.textSize = size
        }
        stroke.textSize = size
        stroke.strokeWidth = size * 0.16f

        val enterAge = (tMs - chunk.startMs).toFloat()
        val enter = easeOutBack((enterAge / 220f).coerceIn(0f, 1f))
        val a = ((enterAge / 90f).coerceIn(0f, 1f) * 255).toInt()
        val baseY = h * (if (portrait) 0.68f else 0.82f) + (1f - enter) * size * 0.5f

        var active = 0
        for (i in chunk.words.indices) if (chunk.words[i].startMs <= tMs) active = i

        val fm = fill.fontMetrics
        var x = (w - total) / 2f
        for (i in texts.indices) {
            val wordW = widths[i]
            val cx = x + wordW / 2f
            x += wordW + gap

            val isActive = i == active
            val age = (tMs - chunk.words[i].startMs).toFloat().coerceAtLeast(0f)
            var scale = 1f
            var dy = 0f
            var rot = 0f
            if (isActive) {
                scale = (0.78f + 0.22f * easeOutBack((age / 200f).coerceIn(0f, 1f))) * 1.1f
                if (st == CaptionStyle.BOUNCE) {
                    val k = (age / 280f).coerceIn(0f, 1f)
                    dy = -sin(k * PI.toFloat()) * size * 0.2f
                    rot = sin(age * 0.06f) * 5f * (1f - k)
                }
            }

            canvas.save()
            canvas.translate(cx, baseY + dy)
            canvas.rotate(rot)
            canvas.scale(scale, scale)

            if (isActive && st == CaptionStyle.BOX) {
                box.color = purple
                box.alpha = a
                val pad = size * 0.16f
                canvas.drawRoundRect(
                    -wordW / 2f - pad, fm.ascent * 0.92f - pad * 0.3f,
                    wordW / 2f + pad, fm.descent + pad * 0.4f,
                    size * 0.2f, size * 0.2f, box
                )
            }

            stroke.color = Color.BLACK
            stroke.alpha = a
            canvas.drawText(texts[i], -wordW / 2f, 0f, stroke)

            fill.color = when {
                isActive && st == CaptionStyle.POP -> yellow
                isActive && st == CaptionStyle.BOUNCE -> green
                else -> Color.WHITE
            }
            fill.alpha = a
            canvas.drawText(texts[i], -wordW / 2f, 0f, fill)
            canvas.restore()
        }
    }
}
