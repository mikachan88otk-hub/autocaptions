package com.example.autocaptions

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Met l'app à jour depuis la dernière release publiée sur le GitHub de l'utilisateur. */
object Updater {
    private const val API = "https://api.github.com/repos/mikachan88otk-hub/autocaptions/releases/latest"

    data class Info(val number: Int, val url: String)

    fun currentVersion(ctx: Context): Int =
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).longVersionCode.toInt()

    /** Dernière release : le nom se termine par le numéro de build (« AutoCaptions APK 7 »). */
    fun latest(): Info? {
        val c = URL(API).openConnection() as HttpURLConnection
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.connectTimeout = 15_000
        c.readTimeout = 15_000
        val body = c.inputStream.bufferedReader().use { it.readText() }
        val j = JSONObject(body)
        val number = Regex("(\\d+)\\s*$").find(j.optString("name"))?.groupValues?.get(1)?.toIntOrNull()
            ?: return null
        val assets = j.getJSONArray("assets")
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.getString("name").endsWith(".apk")) return Info(number, a.getString("browser_download_url"))
        }
        return null
    }

    fun download(ctx: Context, url: String, onProgress: (Int) -> Unit): File {
        val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
        val out = File(dir, "update.apk")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        val total = c.contentLength.toLong()
        c.inputStream.use { input ->
            out.outputStream().use { o ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var last = -1
                while (true) {
                    val r = input.read(buf)
                    if (r < 0) break
                    o.write(buf, 0, r)
                    done += r
                    if (total > 0) {
                        val p = (done * 100 / total).toInt()
                        if (p != last) {
                            last = p
                            onProgress(p)
                        }
                    }
                }
            }
        }
        return out
    }

    fun install(activity: Activity, apk: File) {
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", apk)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(i)
    }
}
