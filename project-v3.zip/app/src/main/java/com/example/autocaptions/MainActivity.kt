package com.example.autocaptions

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model

class MainActivity : ComponentActivity() {

    private lateinit var exo: ExoPlayer
    private val renderer = CaptionRenderer()
    private var videoUri: Uri? = null

    private lateinit var status: TextView
    private lateinit var btnPick: Button
    private lateinit var btnGen: Button
    private lateinit var btnStyle: Button
    private lateinit var btnExport: Button
    private lateinit var btnUpdate: Button

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadVideo(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        renderer.loadFont(this)

        exo = ExoPlayer.Builder(this).build()
        val playerView = PlayerView(this).apply { player = exo }
        val overlay = CaptionOverlayView(this, exo, renderer)

        val frame = FrameLayout(this).apply {
            addView(playerView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(overlay, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        }

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            text = "Choisis une vidéo pour commencer."
            setPadding(0, dp(8), 0, dp(8))
        }

        btnPick = Button(this).apply { text = "📁 Vidéo"; setOnClickListener { picker.launch("video/*") } }
        btnGen = Button(this).apply { text = "✨ Sous-titrer"; isEnabled = false; setOnClickListener { generate() } }
        btnStyle = Button(this).apply {
            text = "🎨 ${renderer.style.label}"
            setOnClickListener {
                val all = CaptionStyle.values()
                renderer.style = all[(renderer.style.ordinal + 1) % all.size]
                text = "🎨 ${renderer.style.label}"
            }
        }
        btnExport = Button(this).apply { text = "💾 Exporter MP4"; isEnabled = false; setOnClickListener { exportVideo() } }
        btnUpdate = Button(this).apply {
            text = "⬆️ Mettre à jour (v${Updater.currentVersion(this@MainActivity)})"
            setOnClickListener { checkUpdate() }
        }

        fun row(vararg b: Button) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            b.forEach { addView(it, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)) }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(12), dp(36), dp(12), dp(12))
            addView(frame, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(status, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(row(btnPick, btnGen), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(row(btnStyle, btnExport), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(row(btnUpdate), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        setContentView(root)
    }

    private fun loadVideo(uri: Uri) {
        videoUri = uri
        renderer.chunks = emptyList()
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        exo.playWhenReady = true
        btnGen.isEnabled = true
        btnExport.isEnabled = false
        status.text = "Vidéo chargée. Appuie sur « Sous-titrer »."
    }

    private fun setBusy(busy: Boolean) {
        btnPick.isEnabled = !busy
        btnGen.isEnabled = !busy && videoUri != null
        btnExport.isEnabled = !busy && renderer.chunks.isNotEmpty()
        btnUpdate.isEnabled = !busy
    }

    private fun checkUpdate() {
        setBusy(true)
        status.text = "Recherche de mise à jour…"
        lifecycleScope.launch {
            try {
                val info = withContext(Dispatchers.IO) { Updater.latest() }
                val current = Updater.currentVersion(this@MainActivity)
                when {
                    info == null -> status.text = "Impossible de lire la dernière version."
                    info.number <= current -> status.text = "✅ Tu as déjà la dernière version (v$current)."
                    !packageManager.canRequestPackageInstalls() -> {
                        status.text = "Autorise l'installation depuis AutoCaptions, puis reviens et réessaie."
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                        )
                    }
                    else -> {
                        status.text = "Téléchargement de la v${info.number}…"
                        val apk = withContext(Dispatchers.IO) {
                            Updater.download(applicationContext, info.url) { p ->
                                runOnUiThread { status.text = "Téléchargement de la v${info.number}… $p%" }
                            }
                        }
                        Updater.install(this@MainActivity, apk)
                    }
                }
            } catch (e: Exception) {
                status.text = "Erreur : ${e.message}"
            } finally {
                setBusy(false)
            }
        }
    }

    private fun generate() {
        val uri = videoUri ?: return
        setBusy(true)
        exo.pause()
        lifecycleScope.launch {
            try {
                val words = withContext(Dispatchers.Default) {
                    val dir = ModelStore.ensure(applicationContext) { s -> runOnUiThread { status.text = s } }
                    status.post { status.text = "Chargement du modèle…" }
                    val model = Model(dir.absolutePath)
                    try {
                        Transcriber.transcribe(applicationContext, uri, model) { p ->
                            runOnUiThread { status.text = "Transcription… ${(p * 100).toInt()}%" }
                        }
                    } finally {
                        model.close()
                    }
                }
                renderer.chunks = Captions.buildChunks(words)
                status.text = if (words.isEmpty()) "Aucune parole détectée." else "✅ ${words.size} mots sous-titrés. Change le style avec 🎨 !"
                exo.seekTo(0)
                exo.play()
            } catch (e: Exception) {
                status.text = "Erreur : ${e.message}"
            } finally {
                setBusy(false)
            }
        }
    }

    private fun exportVideo() {
        val uri = videoUri ?: return
        exo.pause()
        setBusy(true)
        status.text = "Export… 0%"
        try {
            Exporter.export(
                this, uri, renderer,
                onProgress = { p -> status.text = "Export… $p%" },
                onDone = { saved, err ->
                    setBusy(false)
                    status.text = if (saved != null) "✅ Vidéo enregistrée dans Movies/AutoCaptions" else "Erreur d'export : $err"
                }
            )
        } catch (e: Exception) {
            setBusy(false)
            status.text = "Erreur : ${e.message}"
        }
    }

    override fun onDestroy() {
        exo.release()
        super.onDestroy()
    }
}
