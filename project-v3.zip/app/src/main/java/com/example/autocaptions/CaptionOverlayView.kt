package com.example.autocaptions

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.view.View
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.min

/** Superpose les sous-titres animés sur la vidéo pendant la lecture. */
class CaptionOverlayView(
    ctx: Context,
    private val player: ExoPlayer,
    private val renderer: CaptionRenderer
) : View(ctx) {

    override fun onDraw(canvas: Canvas) {
        val vs = player.videoSize
        var vw = vs.width
        var vh = vs.height
        if (vw > 0 && vh > 0) {
            if (vs.unappliedRotationDegrees % 180 != 0) { val t = vw; vw = vh; vh = t }
            val scale = min(width / vw.toFloat(), height / vh.toFloat())
            val rw = vw * scale
            val rh = vh * scale
            canvas.save()
            canvas.translate((width - rw) / 2f, (height - rh) / 2f)
            renderer.draw(canvas, rw.toInt(), rh.toInt(), player.currentPosition)
            canvas.restore()
        }
        postInvalidateOnAnimation()
    }
}
