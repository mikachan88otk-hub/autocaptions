package com.example.autocaptions

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Télécharge (une seule fois) le petit modèle vocal anglais de Vosk (~40 Mo). */
object ModelStore {
    private const val NAME = "vosk-model-small-en-us-0.15"
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/$NAME.zip"

    fun ensure(ctx: Context, onStatus: (String) -> Unit): File {
        val dir = File(ctx.filesDir, NAME)
        val marker = File(dir, ".ok")
        if (marker.exists()) return dir

        val zip = File(ctx.cacheDir, "$NAME.zip")
        val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 20_000
        conn.readTimeout = 30_000
        val total = conn.contentLength.toLong()
        conn.inputStream.use { input ->
            zip.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var lastPct = -1
                while (true) {
                    val r = input.read(buf)
                    if (r < 0) break
                    out.write(buf, 0, r)
                    done += r
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct != lastPct) {
                            lastPct = pct
                            onStatus("Téléchargement du modèle vocal… $pct%")
                        }
                    }
                }
            }
        }

        onStatus("Installation du modèle vocal…")
        val root = ctx.filesDir.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val out = File(ctx.filesDir, e.name)
                if (!out.canonicalPath.startsWith(root)) throw SecurityException("Zip invalide")
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zis.copyTo(it) }
                }
                e = zis.nextEntry
            }
        }
        zip.delete()
        marker.createNewFile()
        return dir
    }
}
