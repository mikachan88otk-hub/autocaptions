package com.example.autocaptions

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.nio.ByteOrder
import java.nio.ShortBuffer

/** Décode la piste audio de la vidéo en PCM 16 kHz mono et la passe à Vosk (hors-ligne). */
object Transcriber {

    fun transcribe(ctx: Context, uri: Uri, model: Model, onProgress: (Float) -> Unit): List<Word> {
        val extractor = MediaExtractor()
        extractor.setDataSource(ctx, uri, null)

        var track = -1
        var fmt: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                track = i
                fmt = f
                break
            }
        }
        if (track < 0 || fmt == null) {
            extractor.release()
            throw IllegalStateException("Cette vidéo n'a pas de piste audio.")
        }
        val format = fmt
        extractor.selectTrack(track)
        val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L

        val codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
        val rec = Recognizer(model, 16000f)
        rec.setWords(true)
        val words = mutableListOf<Word>()
        val sink = PcmSink(rec, words)
        sink.setFormat(format.getInteger(MediaFormat.KEY_SAMPLE_RATE), format.getInteger(MediaFormat.KEY_CHANNEL_COUNT))

        try {
            codec.configure(format, null, null, 0)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var inEos = false
            var outEos = false
            var lastReport = 0L

            while (!outEos) {
                if (!inEos) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inEos = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    o >= 0 -> {
                        val out = codec.getOutputBuffer(o)!!
                        if (info.size > 0) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            sink.feed(out.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer())
                        }
                        codec.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outEos = true
                        if (durationUs > 0 && info.presentationTimeUs - lastReport > 500_000) {
                            lastReport = info.presentationTimeUs
                            onProgress((info.presentationTimeUs.toFloat() / durationUs).coerceIn(0f, 1f))
                        }
                    }
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        sink.setFormat(f.getInteger(MediaFormat.KEY_SAMPLE_RATE), f.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                    }
                }
            }
            sink.flush()
            collect(rec.finalResult, words)
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            extractor.release()
            rec.close()
        }
        return words
    }

    private fun collect(json: String, out: MutableList<Word>) {
        val arr = JSONObject(json).optJSONArray("result") ?: return
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += Word(
                o.getString("word"),
                (o.getDouble("start") * 1000).toLong(),
                (o.getDouble("end") * 1000).toLong()
            )
        }
    }

    /** Mixe en mono, rééchantillonne à 16 kHz (moyenne par blocs) et envoie à Vosk. */
    private class PcmSink(val rec: Recognizer, val words: MutableList<Word>) {
        private var channels = 1
        private var step = 1.0
        private var idx = 0.0
        private var next = 1.0
        private var acc = 0.0
        private var cnt = 0
        private val buf = ByteArray(8000)
        private var n = 0

        fun setFormat(rate: Int, ch: Int) {
            channels = ch
            step = rate / 16000.0
            idx = 0.0
            next = step
            acc = 0.0
            cnt = 0
        }

        fun feed(sb: ShortBuffer) {
            while (sb.remaining() >= channels) {
                var s = 0
                for (c in 0 until channels) s += sb.get().toInt()
                acc += s.toDouble() / channels
                cnt++
                idx += 1.0
                if (idx >= next) {
                    emit((acc / cnt).toInt().toShort())
                    acc = 0.0
                    cnt = 0
                    next += step
                }
            }
        }

        private fun emit(v: Short) {
            buf[n++] = (v.toInt() and 0xFF).toByte()
            buf[n++] = (v.toInt() shr 8).toByte()
            if (n == buf.size) flush()
        }

        fun flush() {
            if (n > 0) {
                if (rec.acceptWaveForm(buf, n)) collect(rec.result, words)
                n = 0
            }
        }
    }
}
